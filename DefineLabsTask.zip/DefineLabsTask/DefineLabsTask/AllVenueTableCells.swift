//
//  AllVenueTableCells.swift
//  DefineLabsTask
//
//  Created by Pushpam on 09/09/21.
//

import Foundation
import UIKit

class AllVenueTableCell:UITableViewCell{
    

    @IBOutlet weak var venueNamelbl: UILabel!
    
    @IBOutlet weak var cityLbl: UILabel!
    
    @IBOutlet weak var stateLbl: UILabel!
    @IBOutlet weak var countryLbl: UILabel!
    
    @IBOutlet weak var starButton: UIButton!
}
