//
//  ListViewController.swift
//  DefineLabsTask
//
//  Created by Pushpam on 08/09/21.
//

import UIKit

class ListViewController: UITableViewController {
    
    let data = ["All Venues","Saved Venues"]

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tableView.backgroundColor = #colorLiteral(red: 0.9568627477, green: 0.6588235497, blue: 0.5450980663, alpha: 1)
        
        //tableView.separatorStyle = .none
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return data.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell",for: indexPath)
        cell.textLabel?.text = data[indexPath.row]
        cell.imageView?.image = UIImage(systemName: "arrow.right")?.withTintColor(.darkGray)
        return cell
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0:
            let selectedUserVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "FirstViewController") as! FirstViewController
            self.navigationController?.pushViewController(selectedUserVC, animated: true)
        
        case 1:
            let selectedUserVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "SavedVenueVc") as! SavedVenueVc
            self.navigationController?.pushViewController(selectedUserVC, animated: true)
        
        default:
            break
        }
    }
    

}
