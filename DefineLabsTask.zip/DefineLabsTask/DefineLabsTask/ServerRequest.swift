//
//  ServerRequest.swift
//  DefineLabsTask
//
//  Created by Pushpam on 09/09/21.
//

import Foundation
class ServerRequest : NSObject {
        
    weak var delegate:NetworkDelegate?
    let url = URL(string: "https://api.foursquare.com/v2/venues/search?ll=40.7484,-73.9857&oauth_token=NPKYZ3WZ1VYMNAZ2FLX1WLECAWSMUVOQZOIDBN53F3LVZBPQ&v=20180616")
    
    func getAllUserData()  {
        
        var request : URLRequest = URLRequest(url: url!)
        request.url = url
        request.httpMethod = "GET"
        request.timeoutInterval = 30
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        let dataTask = URLSession.shared.dataTask(with: request) { [self] (data, response, error) in
            
            if (error != nil) {
                print("error: \(error.debugDescription)")
                delegate?.userDetailsResponse(allVenues: [], allLocations: [], error: error)
                
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, let receivedData = data else {
                print("error: not a valid http response")
                delegate?.userDetailsResponse(allVenues: [], allLocations: [], error: error)
                return
            }
            
            var finalVenueList:[AllVenues] = [AllVenues]()
            var finalLocationlist:[VenueLocation] = [VenueLocation]()
            switch (httpResponse.statusCode) {
            
            case 200:
                let responseJSON = try? JSONSerialization.jsonObject(with: receivedData, options: [])
                if let responseJSON = responseJSON as? [String: Any], let AllVenuesData =  responseJSON["response"] as? [String: Any] {
                    print(responseJSON)
                    let veuesDetails = AllVenuesData["venues"] as? [[String:Any]]
                    //                    if let locatonData = veuesDetails["location"] as? [String:Any]{
                    //
                    //                    }
                    //                    if let venueData = AllVenuesData["venues"] as? [[String:Any]]{
                    //                        print(venueData)
                    //                    }
                    
                    
                    let creditObj = try? JSONDecoder().decode(AllVenues.self, from: receivedData)
                    
                    for location in [veuesDetails]{
                        let encoded  = try? JSONSerialization.data(withJSONObject: location as Any, options: [])
                        if let userLocObj = try? JSONDecoder().decode(VenueLocation.self, from: encoded!) {
                            finalLocationlist.append(userLocObj)
                        }
                    }
                    
                    for Venues in [[veuesDetails]] {
                        let encoded  = try? JSONSerialization.data(withJSONObject: Venues, options: [])
                        if let userObj = try? JSONDecoder().decode(AllVenues.self, from: encoded!) {
                            finalVenueList.append(userObj)
                        }
                    }
                    
                    delegate?.userDetailsResponse(allVenues: finalVenueList, allLocations: finalLocationlist, error: error)
                }
            default:
                print("save profile POST request got response \(httpResponse.statusCode)")
                delegate?.userDetailsResponse(allVenues: [], allLocations: [], error: error)            }
        }
        dataTask.resume()
    }
 
}
