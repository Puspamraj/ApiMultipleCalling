//
//  NetworkDelegate.swift
//  DefineLabsTask
//
//  Created by Pushpam on 09/09/21.
//

import Foundation

protocol NetworkDelegate : NSObjectProtocol {
    
    func userDetailsResponse(allVenues:[AllVenues], allLocations:[VenueLocation], error:Error?)
    
}


