//
//  AllVenuesModel.swift
//  DefineLabsTask
//
//  Created by Pushpam on 09/09/21.
//

import Foundation
