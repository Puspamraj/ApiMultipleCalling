//
//  FirstVC.swift
//  DefineLabsTask
//
//  Created by Pushpam on 08/09/21.
//

import Foundation
import UIKit
import SideMenu
import MBProgressHUD

class FirstViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
 

    
    @IBOutlet weak var allVenuesTable: UITableView!
    
    var menu : SideMenuNavigationController?
    var serverRequest = ServerRequest()
    var nameOfVenue = [AllVenues]()
    var locationModel = [VenueLocation]()
    override func viewDidLoad() {
        super.viewDidLoad()
        allVenuesTable.delegate = self
        allVenuesTable.dataSource = self
        //serverRequest.delegate = self
        menu = SideMenuNavigationController(rootViewController: ListViewController())
        menu?.leftSide = true
        menu?.setNavigationBarHidden(true, animated: true)
        self.callAPI()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.allVenuesTable.reloadData()
    }
    
    func showAlert(msg:String) {
        let alertVC = UIAlertController.init(title: "Alert", message: msg, preferredStyle: .alert)
        let ok = UIAlertAction.init(title: "OK", style: .default) { (alert) in
        }
        alertVC.addAction(ok)
        self.present(alertVC, animated: true, completion: nil)
    }
    
    func callAPI() {
       
        
        MBProgressHUD.showAdded(to: self.view, animated: true)
        self.serverRequest.getAllUserData()
    }
    


    @IBAction func menuTapped(_ sender: Any) {
        present(menu!, animated: true, completion: nil)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return nameOfVenue.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell",for: indexPath) as! AllVenueTableCell
        let tempVenue = nameOfVenue[indexPath.row]
       // let tempLocation = locationModel[indexPath.row]
        
        cell.venueNamelbl.text = tempVenue.name
//        cell.cityLbl.text = tempLocation.city
//        cell.countryLbl.text = tempLocation.country
//        cell.stateLbl.text = tempLocation.state

        
        allVenuesTable.reloadData()
        return cell
    }

    
}

extension FirstViewController: NetworkDelegate {
    func userDetailsResponse(allVenues: [AllVenues], allLocations: [VenueLocation], error: Error?) {
  
        DispatchQueue.main.async {
            MBProgressHUD.hide(for: self.view, animated: true)

            if error != nil {
                // show error alert
                print(error.debugDescription)
                self.showAlert(msg: "The Internet connection appears to be offline")
                
            }
            else {
                self.nameOfVenue = allVenues
                self.locationModel = allLocations
            }
            
            self.allVenuesTable.reloadData()
        }
    }
    
    
    
}
